package com.major.potholerectifier.model;

public enum  PotHoleStatus {
    OPEN,INPROGRESS,COMPLETED
}
