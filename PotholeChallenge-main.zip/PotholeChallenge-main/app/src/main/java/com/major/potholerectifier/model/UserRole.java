package com.major.potholerectifier.model;

enum UserRole {

    PUBLIC,GOVERNMENT
}
